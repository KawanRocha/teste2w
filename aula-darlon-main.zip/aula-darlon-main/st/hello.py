import streamlit as st
st.title("Hello World from Streamlit!!")
st.write("versao 0.2")
